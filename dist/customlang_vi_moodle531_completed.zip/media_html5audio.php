<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost
 *
 * @package    media
 * @subpackage html5audio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Âm thanh HTML5';
$string['pluginname_help'] = 'Tệp âm thanh được phát bằng trình phát âm thanh gốc của trình duyệt. (Khả năng hỗ trợ định dạng tùy thuộc vào trình duyệt.)';
$string['privacy:metadata'] = 'Plugin phương tiện âm thanh HTML5 không lưu trữ dữ liệu cá nhân.';
