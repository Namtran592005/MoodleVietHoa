<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost
 *
 * @package    datafield
 * @subpackage textarea
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['fieldtypelabel'] = 'Vùng văn bản';
$string['maxbytes'] = 'Kích thước tệp nhúng tối đa (byte)';
$string['maxbytes_desc'] = 'Nếu đặt bằng 0, kích thước sẽ không bị giới hạn theo mặc định';
$string['pluginname'] = 'Vùng văn bản';
$string['privacy:metadata'] = 'Thành phần trường Vùng văn bản không lưu trữ dữ liệu cá nhân; thành phần này sử dụng các bảng được định nghĩa trong mod_data.';
$string['sample'] = '<p>Đây là vùng văn bản. Vùng này cho phép người dùng nhập văn bản dài trên nhiều dòng.</p><p>Bạn có thể chọn kích thước vùng văn bản theo số hàng và số cột.</p><p>Văn bản trong vùng văn bản có thể được định dạng, chẳng hạn như <strong>in đậm</strong>, đồng thời có thể bao gồm <a href="#">liên kết</a> hoặc hình ảnh.</p>';
