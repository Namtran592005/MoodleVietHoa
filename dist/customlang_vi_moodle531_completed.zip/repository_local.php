<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost
 *
 * @package    repository
 * @subpackage local
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['configplugin'] = 'Cấu hình kho lưu trữ tệp trên máy chủ';
$string['currentusefiles'] = 'Các tệp hiện đang được sử dụng';
$string['emptyfilelist'] = 'Không có tệp nào để hiển thị';
$string['local:view'] = 'Xem kho lưu trữ trên máy chủ';
$string['notitle'] = 'notitle';
$string['pluginname'] = 'Tệp trên máy chủ';
$string['pluginname_help'] = 'Các tệp đã tải lên máy chủ Moodle trước đây';
$string['privacy:metadata'] = 'Plugin kho lưu trữ tệp trên máy chủ không lưu trữ hoặc truyền bất kỳ dữ liệu cá nhân nào.';
$string['remember'] = 'Ghi nhớ tôi';
