<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost
 *
 * @package    profilefield
 * @subpackage checkbox
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Hộp kiểm';
$string['privacy:metadata:profilefield_checkbox:data'] = 'Dữ liệu người dùng của trường hồ sơ người dùng Hộp kiểm';
$string['privacy:metadata:profilefield_checkbox:dataformat'] = 'Định dạng dữ liệu người dùng của trường hồ sơ người dùng Hộp kiểm';
$string['privacy:metadata:profilefield_checkbox:fieldid'] = 'ID của trường hồ sơ';
$string['privacy:metadata:profilefield_checkbox:tableexplanation'] = 'Dữ liệu hồ sơ bổ sung';
$string['privacy:metadata:profilefield_checkbox:userid'] = 'ID của người dùng có dữ liệu được lưu bởi trường hồ sơ người dùng Hộp kiểm';
