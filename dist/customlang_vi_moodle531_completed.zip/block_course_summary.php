<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost
 *
 * @package    block
 * @subpackage course_summary
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['course_summary:addinstance'] = 'Thêm khối tóm tắt khóa học/trang mới';
$string['coursesummary'] = 'Tóm tắt khóa học';
$string['pluginname'] = 'Tóm tắt khóa học/trang';
$string['privacy:metadata'] = 'Khối Tóm tắt khóa học/trang chỉ hiển thị thông tin về khóa học và không tự lưu trữ dữ liệu.';
