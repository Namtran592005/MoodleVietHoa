<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost
 *
 * @package    quizaccess
 * @subpackage delaybetweenattempts
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Quy tắc truy cập bài kiểm tra về thời gian chờ giữa các lần làm bài';
$string['privacy:metadata'] = 'Plugin quy tắc truy cập bài kiểm tra về thời gian chờ giữa các lần làm bài không lưu trữ dữ liệu cá nhân.';
$string['youcannotwait'] = 'Bài kiểm tra này sẽ đóng trước khi bạn được phép bắt đầu lần làm bài tiếp theo.';
$string['youmustwait'] = 'Bạn phải chờ trước khi có thể làm lại bài kiểm tra này. Bạn sẽ được phép bắt đầu lần làm bài tiếp theo sau {$a}.';
