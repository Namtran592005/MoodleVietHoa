<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost
 *
 * @package    block
 * @subpackage completionstatus
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['completionprogressdetails'] = 'Chi tiết tiến độ hoàn thành';
$string['completionstatus:addinstance'] = 'Thêm khối trạng thái hoàn thành khóa học mới';
$string['criteriagroup'] = 'Nhóm tiêu chí';
$string['firstofsecond'] = '{$a->first} trên {$a->second}';
$string['pluginname'] = 'Trạng thái hoàn thành khóa học';
$string['privacy:metadata'] = 'Khối Trạng thái hoàn thành khóa học chỉ hiển thị thông tin về việc hoàn thành khóa học và không lưu trữ dữ liệu riêng.';
$string['requirement'] = 'Yêu cầu';
$string['returntocourse'] = 'Quay lại khóa học';
