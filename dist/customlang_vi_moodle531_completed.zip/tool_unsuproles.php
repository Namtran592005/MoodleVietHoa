<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost
 *
 * @package    tool
 * @subpackage unsuproles
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['confirmdelete'] = 'Bạn có thực sự muốn xóa tất cả các phân công vai trò không được hỗ trợ cho vai trò "{$a->role}" ở cấp ngữ cảnh "{$a->level}" không?';
$string['contextlevel'] = 'Cấp ngữ cảnh';
$string['count'] = 'Số lượng';
$string['noprolbems'] = 'Không tìm thấy phân công vai trò nào không được hỗ trợ.';
$string['pluginname'] = 'Phân công vai trò không được hỗ trợ';
$string['privacy:metadata'] = 'Plugin Phân công vai trò không được hỗ trợ không lưu trữ dữ liệu cá nhân nào.';
