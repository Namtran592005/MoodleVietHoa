<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost
 *
 * @package    qbank
 * @subpackage usage
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['attempts'] = 'Lần làm bài';
$string['coursename'] = 'Tên khóa học';
$string['modulename'] = 'Tên hoạt động';
$string['notused'] = 'Chưa bao giờ';
$string['pluginname'] = 'Mức sử dụng câu hỏi';
$string['privacy:metadata'] = 'Plugin ngân hàng câu hỏi Mức sử dụng câu hỏi không lưu trữ dữ liệu cá nhân.';
$string['questionlastused'] = 'Lần sử dụng gần nhất';
$string['questionlastused_help'] = 'Ngày câu hỏi được làm lần gần nhất.';
$string['questionusage'] = 'Mức sử dụng';
$string['questionusage_help'] = 'Số lượng bài kiểm tra có sử dụng câu hỏi, kèm liên kết mở cửa sổ liệt kê các bài kiểm tra và số lần làm bài.';
$string['questionusageversion'] = 'v{$a}';
$string['state'] = 'Trạng thái';
$string['usageheader'] = 'Mức sử dụng câu hỏi';
$string['versions'] = 'Phiên bản';
